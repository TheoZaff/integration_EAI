﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class displayCard : MonoBehaviour {

	// Use this for initialization
	void Start () {
		//recuperer from du getDialogue

		//if (from == "ASS"){ afficher texte }
	}
	
	// Update is called once per frame
		void Update () {
		
	}
}
