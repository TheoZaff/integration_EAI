﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class displayBulle : MonoBehaviour {

	// Use this for initialization
	void Start () {
		//recuperer from du getDialogue

		//if (from == "patient"){ afficher texte }
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
